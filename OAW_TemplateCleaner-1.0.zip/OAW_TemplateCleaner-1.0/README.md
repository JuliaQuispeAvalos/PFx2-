# OAW_TemplateCleaner
> Detalles:
> - Versión: **1.2**
> - Código: **PowerShell**
> - Publicado: **10-NOV-2019**

> Descripción: 
> - Soy una solución nueva, porfavor hacer una copia su **`"TEMPLATE"`** antes de usarme.

> Pasos a seguir:
>	- Asegurese de que no exista una carpeta **"resources"** en su template.
>	- Execute el archivo **"RUN.bat"**.
>	- Arrastre su Template del la consola.
>	- Espere hasta que termine, de lo contrario puede causar errores.
>	- De tener algún error/sugerencia/duda comuniquese con mi creador para seguir evolucionando.
